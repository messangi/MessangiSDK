//
//  DeviceUID.h
//  MessangiSDK
//
//  Created by William Añez on 12/15/15.
//  Copyright (c) 2016 Ogangi. All rights reserved.
//

#ifndef DeviceUID_h
#define DeviceUID_h

#import <Foundation/Foundation.h>

@interface DeviceUID : NSObject

+ (NSString *)uid;

@end

#endif /* DeviceUID_h */

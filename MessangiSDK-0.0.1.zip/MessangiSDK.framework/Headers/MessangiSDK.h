//
//  MessangiSDK2.h
//  MessangiSDK2
//
//  Created by Bgonzalez on 12/21/17.
//  Copyright © 2017 Ogangi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Messangi.h"
#import "Message.h"

#import "DeviceSubscriber.h"

#import "SingleMessageLoader.h"
#import "PendingMessageDataLoader.h"

#import "RegisterPhoneDataloader.h"
#import "CheckGeoFences.h"
#import "LoadBeacons.h"
#import "DeviceUID.h"
#import "DeviceSubscriber.h"

#import "Workspace.h"
#import "WorkspaceDataLoader.h"

#import "LocationDataLoader.h"

#import "EventLogger.h"

//! Project version number for MessangiSDK2.
FOUNDATION_EXPORT double MessangiSDK2VersionNumber;

//! Project version string for MessangiSDK2.
FOUNDATION_EXPORT const unsigned char MessangiSDK2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MessangiSDK2/PublicHeader.h>


//
//  RegisterPhoneDataloader.h
//  Messangi
//
//  Created by Omar Diaz on 05/11/13.
//  Copyright (c) 2016 Ogangi. All rights reserved.
//

#ifndef DeviceSuscriberDelegate_H
#define DeviceSuscriberDelegate_H

#import <Foundation/Foundation.h>

@protocol RegisterPhoneDelegate <NSObject>
@required

- (void)RegistrationStatus:(BOOL)successful andRequireValidation:(BOOL)validation withMessage:(NSString *)message;

- (void)UnRegisterUserSucceeded:(BOOL)successful;

- (void)UnRegisterUserError:(NSString *)error;

- (void)RegistrationThrowsError:(NSString *)error;

/*!
 *  @brief  When activatePhoneWithCode work successfully, call this method
 *  @param success true
 *  @param message Response from Server
 */
- (void)ActivatePhoneSucceeded:(BOOL)success withMessage:(NSString *)message;

/*!
 *  @brief  When activatePhoneWithCode fail, call this method
 *  @param error Error message from Server
 */
- (void)ActivatePhoneReturnedError:(NSString *)error;

@end

/*!
 *  @brief  Interface for User Registration, need Implement for Own Registration Dialog
 */
@interface RegisterPhoneDataloader : NSObject <NSXMLParserDelegate>
{
	NSMutableString *currentStringValue;
	NSString *currentProperty;
	id <RegisterPhoneDelegate> delegate;
}

@property BOOL successful;
@property BOOL requireValidation;
@property (strong) NSString *message;
@property int operation;
@property (retain) id delegate;
@property (nonatomic, strong) NSMutableString *currentStringValue;
@property (nonatomic, strong) NSString *currentProperty;

/*!
 *  @brief  Send a Identification Token to Messangi Backend
 *  @param userID     Identification Token
 *  @param validation Exectute a two steap validation
 */
- (void) registerUserWithID:(NSString *)userID andWaitForActivation:(Boolean) validation;

- (void) unRegisterUser;

/*!
 *  @brief  Send Validation Code received by SMS to Messangi Backend
 *  @param code Code Received by SMS
 */
- (void)activatePhoneWithCode:(NSString *)code;

@end

#endif

//
//  Messangi.h
//  Messangi
//
//  Created by Francisco Andrades Grassi on 6/2/14.
//  Copyright (c) 2016 Ogangi. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <NetworkExtension/NetworkExtension.h>
#import <SystemConfiguration/CaptiveNetwork.h>

#ifndef MessangiConstants
#define MessangiConstants

#define CURRENT_VERSION                                     @"3.7.0"
// #define PREFIX                                              @"https://api.messangi.com/messangi-staging/rest/message"
#define DISTANCE_UPDATE                                     25
#define VALIDATION_CODE_LENGTH                              5
#define MAX_REGIONS                                         20

#pragma mark Following constants needs analysis fine-tuning

#define GEOFENCELIST_METER_UPDATE_THRESHOLD                 50

#endif

#import "Message.h"

#import "DeviceSubscriber.h"

#import "SingleMessageLoader.h"
#import "PendingMessageDataLoader.h"

#import "RegisterPhoneDataloader.h"
#import "CheckGeoFences.h"
#import "LoadBeacons.h"
#import "DeviceUID.h"
#import "DeviceSubscriber.h"

#import "Workspace.h"
#import "WorkspaceDataLoader.h"

#import "LocationDataLoader.h"

#import "EventLogger.h"

@protocol MessangiProtocol <NSObject>
@required
- (void) pushReceived:(Message *) message fromWorkspace:(Workspace *)workspace;

@optional
- (void) MessangiReady;
- (void) pushReceived:(Message *) message;

@end

@interface Messangi : NSObject <CLLocationManagerDelegate, DeviceSubscriberDelegate, PendingMessageDataLoaderDelegate, WorkspaceDelegate, WorkspaceProtocol, LocationDelegate, UITextFieldDelegate>

#pragma mark Properties
@property id <MessangiProtocol> delegate;
@property NSMutableDictionary *backgroundTasks;


/*! @brief  Central point for configuring the delivery of location- and heading-related events
 */
@property (nonatomic, strong) CLLocationManager *messangiLM;

/*!
 *  @brief  Last location of device
 */
@property (nonatomic, strong) CLLocation *messangiLastLocation;


/*!
 *  @brief  Set of geoFences after added geoFencesToAdd and removed geoFencesToDelete
 */
@property (nonatomic, strong) NSMutableOrderedSet *geoFencesList;

/*!
 *  @brief  Set of beacons after added beaconsToAdd and removed beaconsToDelete
 */
@property (nonatomic, strong) NSMutableOrderedSet *beaconsList;

/*!
 *  @brief  Name of APP
 */
@property (nonatomic, strong) NSString *appName;

/*!
 *  @brief  Client ID
 */
@property (nonatomic, strong) NSString *clientID;

/*!
 *  @brief  Private Key
 */
@property (nonatomic, strong) NSString *apiClientPrivateKey;

/*!
 *  @brief Boolean for use Messangi is Activate
 */
@property (nonatomic) BOOL useMessangiSDK;
@property (nonatomic) double lastPendingMessagesFetch;

#pragma mark Class methods

+ (long) timeStamp;
+ (NSString *) encodeString:(NSString *)data usingKey:(NSString *)key;
+ (NSString *) getSDKVersionString;

- (BOOL) locationServicesAreEnabled;

#pragma  mark - Setting;
- (void) setAppName:(NSString *)newName ;
- (void) setClientID:(NSString *)newClientID ;
- (void) setApiClientPrivateKey:(NSString *)newPrivateKey ;
- (void) setLogAllEventsDisabled:(BOOL)disabled ;
- (BOOL) isLogAllEventsDisabled ;
- (void) setGetLocationDisabled:(BOOL)disabled ;
- (BOOL) isGetLocationDisabled ;
- (void) setMaxStoredMessages:(int)maxMessage;
- (void) loadEnvironmentFromFile:(NSString *)file;
- (void) loadMessangiCredentials:(NSString *)file;

+ (Messangi *) sharedInstance;
+ (void) configure;
- (void) initMessangi;
- (void) registerDialog;
- (void) registerWithUserID:(NSString*) userId;
- (void) unRegisterUser;

#pragma mark Multiple push notification
- (void)getUnreadMessagesWithHandler:(void (^)(UIBackgroundFetchResult))completionHandler ;

#pragma Mark: LocationManager for Beacons and Geofences
- (void) forceUpdateLocation;
- (void) refreshMonitoredRegionsToClosest;
- (void) resetMonitoringRegions;
- (NSSet *)monitoredGeoFences;

#pragma mark Unique Device ID
- (void)registerDeviceToken:(NSData *)deviceToken;

#pragma  mark - Notifications;
- (void) processRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;

#pragma  mark - Loggin and Analytics;
#warning This method is only for default Workspace, if you are using multiple workspaces please use logEvent:andExtraInfo:withCampaignName:andWorkspace instead
- (void) logEvent:(NSString *)eventType andExtraInfo:(NSString *)extraInfo withCampaignName:(NSString *)campaignName;
- (void) logEvent:(NSString *)eventType andExtraInfo:(NSString *)extraInfo withCampaignName:(NSString *)campaignName andWorkspace:(Workspace *)workspace;

#pragma  mark - Workspaces;
- (void) initWorkspaces;

- (void) joinWorkspace:(Workspace *)workspace withCompletionHandler:(void (^)(UIBackgroundFetchResult)) completionHandler;
- (void) leaveWorkspace:(Workspace *)workspace withCompletionHandler:(void (^)(UIBackgroundFetchResult)) completionHandler;

//Revisado
- (void) fetchAvailableWorkspacesWithCompletionHandler:(void (^)(UIBackgroundFetchResult)) completionHandler;
//Revisado
- (void) fetchSubscribedWorkspacesWithCompletionHandler:(void (^)(UIBackgroundFetchResult)) completionHandler;
//Revisado
- (void) getAvailableWorkspaceswithFilter:(NSString *) filter andCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler;
//Revisado
- (NSArray *) getAvailableWorkspaces;
//Revisado
- (NSArray *) getSubscribedWorkspaces;

- (Workspace *) getWorkspaceWithClientID:(NSString *)clientID;
- (Workspace *) getDefaultWorkspace;

@end
